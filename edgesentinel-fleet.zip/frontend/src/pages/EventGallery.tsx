import React from 'react'

const EventGallery: React.FC = () => {
  return (
    <div className="page">
      <h2>Event Gallery</h2>
      <p>Placeholder for inference event gallery with filtering and visualization.</p>
      {/* In a real app, this would show events, images (if stored), confidence scores, etc. */}
    </div>
  )
}

export default EventGallery