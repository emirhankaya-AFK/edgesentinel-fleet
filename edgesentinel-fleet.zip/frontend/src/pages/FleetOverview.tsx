import React from 'react'

const FleetOverview: React.FC = () => {
  return (
    <div className="page">
      <h2>Fleet Overview</h2>
      <p>Placeholder for fleet overview dashboard.</p>
      {/* In a real app, this would show maps, device status, etc. */}
    </div>
  )
}

export default FleetOverview