import React from 'react'

const DriftDashboard: React.FC = () => {
  return (
    <div className="page">
      <h2>Drift Dashboard</h2>
      <p>Placeholder for drift metrics computed from event confidence and feature stats.</p>
      {/* In a real app, this would show charts and graphs for drift detection. */}
    </div>
  )
}

export default DriftDashboard