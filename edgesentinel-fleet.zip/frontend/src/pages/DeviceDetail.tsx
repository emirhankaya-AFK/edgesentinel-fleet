import React from 'react'
import { useParams } from 'react-router-dom'

const DeviceDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>()

  return (
    <div className="page">
      <h2>Device Detail</h2>
      {id ? (
        <p>Showing details for device ID: {id}</p>
      ) : (
        <p>Listing all devices</p>
      )}
      {/* In a real app, this would show device info, streams, etc. */}
    </div>
  )
}

export default DeviceDetail