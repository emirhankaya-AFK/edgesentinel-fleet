import React from 'react'

const ModelRollout: React.FC = () => {
  return (
    <div className="page">
      <h2>Model Rollout</h2>
      <p>Placeholder for model version management and rollout states.</p>
      {/* In a real app, this would show model registry, rollout progress, etc. */}
    </div>
  )
}

export default ModelRollout