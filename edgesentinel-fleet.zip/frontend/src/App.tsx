import React from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import FleetOverview from './pages/FleetOverview'
import DeviceDetail from './pages/DeviceDetail'
import ModelRollout from './pages/ModelRollout'
import EventGallery from './pages/EventGallery'
import DriftDashboard from './pages/DriftDashboard'
import AlertWorkflow from './pages/AlertWorkflow'
import HumanReview from './pages/HumanReview'

function App() {
  return (
    <Router>
      <div className="app">
        <header className="app-header">
          <h1>EdgeSentinel</h1>
          <nav>
            <Link to="/">Fleet Overview</Link>
            <Link to="/devices">Devices</Link>
            <Link to="/models">Model Rollout</Link>
            <Link to="/events">Event Gallery</Link>
            <Link to="/drift">Drift Dashboard</Link>
            <Link to="/alerts">Alerts</Link>
            <Link to="/review">Human Review</Link>
          </nav>
        </header>
        <main className="app-main">
          <Routes>
            <Route path="/" element={<FleetOverview />} />
            <Route path="/devices" element={<DeviceDetail />} />
            <Route path="/models" element={<ModelRollout />} />
            <Route path="/events" element={<EventGallery />} />
            <Route path="/drift" element={<DriftDashboard />} />
            <Route path="/alerts" element={<AlertWorkflow />} />
            <Route path="/review" element={<HumanReview />} />
            <Route path="/device/:id" element={<DeviceDetail />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App