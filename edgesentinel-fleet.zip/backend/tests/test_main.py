from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_read_main():
    response = client.get("/")
    # We don't have a root endpoint yet, so we expect 404
    # But we can check that the app is running
    assert response.status_code == 404