from fastapi import APIRouter
from app.api.v1.endpoints import devices, models, events, alerts, feedback, audit

api_router = APIRouter()
api_router.include_router(devices.router, prefix="/devices", tags=["devices"])
api_router.include_router(models.router, prefix="/models", tags=["models"])
api_router.include_router(events.router, prefix="/events", tags=["events"])
api_router.include_router(alerts.router, prefix="/alerts", tags=["alerts"])
api_router.include_router(feedback.router, prefix="/feedback", tags=["feedback"])
api_router.include_router(audit.router, prefix="/audit", tags=["audit"])