from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.crud import model as crud_model
from app.schemas.model import ModelVersion, ModelVersionCreate, ModelVersionUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=ModelVersion, status_code=status.HTTP_201_CREATED)
def create_model_version(model: ModelVersionCreate, db: Session = Depends(get_db)):
    db_model = crud_model.get_model_version_by_name_and_version(
        db, model_name=model.model_name, version=model.version
    )
    if db_model:
        raise HTTPException(
            status_code=400,
            detail="Model version with this name and version already exists"
        )
    return crud_model.create_model_version(db=db, model=model)


@router.get("/", response_model=List[ModelVersion])
def read_model_versions(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    models = crud_model.get_model_versions(db, skip=skip, limit=limit)
    return models


@router.get("/{model_version_id}", response_model=ModelVersion)
def read_model_version(model_version_id: int, db: Session = Depends(get_db)):
    db_model = crud_model.get_model_version(db, model_version_id=model_version_id)
    if db_model is None:
        raise HTTPException(status_code=404, detail="Model version not found")
    return db_model


@router.put("/{model_version_id}", response_model=ModelVersion)
def update_model_version(model_version_id: int, model: ModelVersionUpdate, db: Session = Depends(get_db)):
    db_model = crud_model.update_model_version(db, model_version_id=model_version_id, model=model)
    if db_model is None:
        raise HTTPException(status_code=404, detail="Model version not found")
    return db_model


@router.delete("/{model_version_id}", response_model=ModelVersion)
def delete_model_version(model_version_id: int, db: Session = Depends(get_db)):
    db_model = crud_model.delete_model_version(db, model_version_id=model_version_id)
    if db_model is None:
        raise HTTPException(status_code=404, detail="Model version not found")
    return db_model