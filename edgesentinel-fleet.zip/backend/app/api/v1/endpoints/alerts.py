from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.crud import alert as crud_alert
from app.schemas.alert import Alert, AlertCreate, AlertUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=Alert, status_code=status.HTTP_201_CREATED)
def create_alert(alert: AlertCreate, db: Session = Depends(get_db)):
    return crud_alert.create_alert(db=db, alert=alert)


@router.get("/", response_model=List[Alert])
def read_alerts(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    alerts = crud_alert.get_alerts(db, skip=skip, limit=limit)
    return alerts


@router.get("/{alert_id}", response_model=Alert)
def read_alert(alert_id: int, db: Session = Depends(get_db)):
    db_alert = crud_alert.get_alert(db, alert_id=alert_id)
    if db_alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    return db_alert


@router.put("/{alert_id}", response_model=Alert)
def update_alert(alert_id: int, alert: AlertUpdate, db: Session = Depends(get_db)):
    db_alert = crud_alert.update_alert(db, alert_id=alert_id, alert=alert)
    if db_alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    return db_alert


@router.delete("/{alert_id}", response_model=Alert)
def delete_alert(alert_id: int, db: Session = Depends(get_db)):
    db_alert = crud_alert.delete_alert(db, alert_id=alert_id)
    if db_alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    return db_alert