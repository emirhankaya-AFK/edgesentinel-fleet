from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.crud import feedback as crud_feedback
from app.schemas.feedback import Feedback, FeedbackCreate, FeedbackUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=Feedback, status_code=status.HTTP_201_CREATED)
def create_feedback(feedback: FeedbackCreate, db: Session = Depends(get_db)):
    return crud_feedback.create_feedback(db=db, feedback=feedback)


@router.get("/", response_model=List[Feedback])
def read_feedback(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    feedbacks = crud_feedback.get_feedback(db, skip=skip, limit=limit)
    return feedbacks


@router.get("/{feedback_id}", response_model=Feedback)
def read_feedback(feedback_id: int, db: Session = Depends(get_db)):
    db_feedback = crud_feedback.get_feedback(db, feedback_id=feedback_id)
    if db_feedback is None:
        raise HTTPException(status_code=404, detail="Feedback not found")
    return db_feedback


@router.put("/{feedback_id}", response_model=Feedback)
def update_feedback(feedback_id: int, feedback: FeedbackUpdate, db: Session = Depends(get_db)):
    db_feedback = crud_feedback.update_feedback(db, feedback_id=feedback_id, feedback=feedback)
    if db_feedback is None:
        raise HTTPException(status_code=404, detail="Feedback not found")
    return db_feedback


@router.delete("/{feedback_id}", response_model=Feedback)
def delete_feedback(feedback_id: int, db: Session = Depends(get_db)):
    db_feedback = crud_feedback.delete_feedback(db, feedback_id=feedback_id)
    if db_feedback is None:
        raise HTTPException(status_code=404, detail="Feedback not found")
    return db_feedback