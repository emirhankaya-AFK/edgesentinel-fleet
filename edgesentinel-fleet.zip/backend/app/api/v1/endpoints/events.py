from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Any

from app.crud import event as crud_event
from app.schemas.event import InferenceEvent, InferenceEventCreate, InferenceEventUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=InferenceEvent, status_code=status.HTTP_201_CREATED)
def create_event(event: InferenceEventCreate, db: Session = Depends(get_db)):
    return crud_event.create_event(db=db, event=event)


@router.get("/", response_model=List[InferenceEvent])
def read_events(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    events = crud_event.get_events(db, skip=skip, limit=limit)
    return events


@router.get("/{event_id}", response_model=InferenceEvent)
def read_event(event_id: int, db: Session = Depends(get_db)):
    db_event = crud_event.get_event(db, event_id=event_id)
    if db_event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    return db_event


@router.put("/{event_id}", response_model=InferenceEvent)
def update_event(event_id: int, event: InferenceEventUpdate, db: Session = Depends(get_db)):
    db_event = crud_event.update_event(db, event_id=event_id, event=event)
    if db_event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    return db_event


@router.delete("/{event_id}", response_model=InferenceEvent)
def delete_event(event_id: int, db: Session = Depends(get_db)):
    db_event = crud_event.delete_event(db, event_id=event_id)
    if db_event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    return db_event