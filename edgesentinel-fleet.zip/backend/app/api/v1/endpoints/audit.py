from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.crud import audit as crud_audit
from app.schemas.audit import AuditLog, AuditLogCreate, AuditLogUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=AuditLog, status_code=status.HTTP_201_CREATED)
def create_audit_log(audit_log: AuditLogCreate, db: Session = Depends(get_db)):
    return crud_audit.create_audit_log(db=db, audit_log=audit_log)


@router.get("/", response_model=List[AuditLog])
def read_audit_logs(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    audit_logs = crud_audit.get_audit_logs(db, skip=skip, limit=limit)
    return audit_logs


@router.get("/{audit_log_id}", response_model=AuditLog)
def read_audit_log(audit_log_id: int, db: Session = Depends(get_db)):
    db_audit_log = crud_audit.get_audit_log(db, audit_log_id=audit_log_id)
    if db_audit_log is None:
        raise HTTPException(status_code=404, detail="Audit log not found")
    return db_audit_log


@router.put("/{audit_log_id}", response_model=AuditLog)
def update_audit_log(audit_log_id: int, audit_log: AuditLogUpdate, db: Session = Depends(get_db)):
    db_audit_log = crud_audit.update_audit_log(db, audit_log_id=audit_log_id, audit_log=audit_log)
    if db_audit_log is None:
        raise HTTPException(status_code=404, detail="Audit log not found")
    return db_audit_log


@router.delete("/{audit_log_id}", response_model=AuditLog)
def delete_audit_log(audit_log_id: int, db: Session = Depends(get_db)):
    db_audit_log = crud_audit.delete_audit_log(db, audit_log_id=audit_log_id)
    if db_audit_log is None:
        raise HTTPException(status_code=404, detail="Audit log not found")
    return db_audit_log