from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.crud import device as crud_device
from app.schemas.device import Device, DeviceCreate, DeviceUpdate
from app.core.database import get_db

router = APIRouter()


@router.post("/", response_model=Device, status_code=status.HTTP_201_CREATED)
def create_device(device: DeviceCreate, db: Session = Depends(get_db)):
    db_device = crud_device.get_device_by_device_id(db, device_id=device.device_id)
    if db_device:
        raise HTTPException(
            status_code=400,
            detail="Device with this device_id already exists"
        )
    return crud_device.create_device(db=db, device=device)


@router.get("/", response_model=List[Device])
def read_devices(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    devices = crud_device.get_devices(db, skip=skip, limit=limit)
    return devices


@router.get("/{device_id}", response_model=Device)
def read_device(device_id: int, db: Session = Depends(get_db)):
    db_device = crud_device.get_device(db, device_id=device_id)
    if db_device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    return db_device


@router.put("/{device_id}", response_model=Device)
def update_device(device_id: int, device: DeviceUpdate, db: Session = Depends(get_db)):
    db_device = crud_device.update_device(db, device_id=device_id, device=device)
    if db_device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    return db_device


@router.delete("/{device_id}", response_model=Device)
def delete_device(device_id: int, db: Session = Depends(get_db)):
    db_device = crud_device.delete_device(db, device_id=device_id)
    if db_device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    return db_device