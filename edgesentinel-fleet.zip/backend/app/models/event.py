from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class InferenceEvent(Base):
    __tablename__ = "inference_events"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    model_version_id = Column(Integer, ForeignKey("model_versions.id"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    confidence = Column(Float)
    # Features or metadata stored as JSON
    features = Column(JSON, nullable=True)
    # For drift calculation, we might store feature statistics
    is_anomaly = Column(Boolean, default=False)
    # Optional: path to stored image (if we were storing images, but we are simulating)
    image_path = Column(String, nullable=True)

    # Relationships
    device = relationship("Device", back_populates="events")
    model_version = relationship("ModelVersion", back_populates="events")