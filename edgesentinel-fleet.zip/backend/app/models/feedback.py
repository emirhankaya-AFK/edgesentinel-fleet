from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("inference_events.id"))
    device_id = Column(Integer, ForeignKey("devices.id"))
    reviewer_id = Column(String)  # Could be a user ID from auth system
    feedback_type = Column(String)  # e.g., "correct", "incorrect", "needs_review"
    comments = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    device = relationship("Device", back_populates="feedback")
    # event = relationship("InferenceEvent")  # Optional