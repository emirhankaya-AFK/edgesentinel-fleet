import random
import numpy as np
from typing import Dict, Any, Tuple
from datetime import datetime, timedelta


def generate_synthetic_image_data(width: int = 640, height: int = 480) -> Dict[str, Any]:
    """
    Generate synthetic image data (as a dictionary of features) for mock inference.
    In a real scenario, this would be an actual image, but for simulation we generate features.
    """
    # Generate some random features that might be extracted from an image
    features = {
        "brightness": random.uniform(0, 255),
        "contrast": random.uniform(0, 100),
        "entropy": random.uniform(0, 10),
        "histogram_mean": random.uniform(0, 255),
        "histogram_std": random.uniform(0, 50),
        "edge_density": random.uniform(0, 1),
        "color_histogram_r": [random.uniform(0, 255) for _ in range(10)],
        "color_histogram_g": [random.uniform(0, 255) for _ in range(10)],
        "color_histogram_b": [random.uniform(0, 255) for _ in range(10)],
    }
    return features


def mock_inference(
    model_name: str,
    model_version: str,
    features: Dict[str, Any]
) -> Tuple[float, bool]:
    """
    Simulate a vision inference model. Returns a confidence score and whether it's an anomaly.
    This is a deterministic mock based on the features.
    """
    # Simple deterministic function based on features
    # We'll use the brightness and entropy to compute a confidence
    brightness = features.get("brightness", 128)
    entropy = features.get("entropy", 5)
    
    # Normalize brightness to 0-1 range (assuming 0-255)
    brightness_norm = brightness / 255.0
    
    # Confidence: higher brightness and lower entropy -> higher confidence (simulating clear image)
    confidence = 0.5 + 0.4 * brightness_norm - 0.3 * (entropy / 10.0)
    confidence = max(0.0, min(1.0, confidence))  # Clamp to 0-1
    
    # Anomaly detection: if confidence is low or entropy is high, mark as anomaly
    is_anomaly = confidence < 0.3 or entropy > 8.0
    
    return confidence, is_anomaly


def generate_drift_metrics(events: list) -> Dict[str, Any]:
    """
    Compute drift metrics from a list of events.
    For simplicity, we'll compute the mean and std of confidence over time.
    """
    if not events:
        return {
            "confidence_mean": 0.0,
            "confidence_std": 0.0,
            "confidence_trend": "stable",
            "anomaly_rate": 0.0
        }
    
    confidences = [e.confidence for e in events if e.confidence is not None]
    anomalies = [e.is_anomaly for e in events if e.is_anomaly is not None]
    
    if not confidences:
        return {
            "confidence_mean": 0.0,
            "confidence_std": 0.0,
            "confidence_trend": "stable",
            "anomaly_rate": 0.0
        }
    
    mean_conf = sum(confidences) / len(confidences)
    # Calculate standard deviation
    variance = sum((x - mean_conf) ** 2 for x in confidences) / len(confidences)
    std_conf = variance ** 0.5
    
    # Trend: compare first half and second half
    split = len(confidences) // 2
    if split > 0:
        first_half = confidences[:split]
        second_half = confidences[split:]
        mean_first = sum(first_half) / len(first_half) if first_half else 0
        mean_second = sum(second_half) / len(second_half) if second_half else 0
        if mean_second > mean_first + 0.05:
            trend = "improving"
        elif mean_second < mean_first - 0.05:
            trend = "degrading"
        else:
            trend = "stable"
    else:
        trend = "stable"
    
    anomaly_rate = sum(anomalies) / len(anomalies) if anomalies else 0.0
    
    return {
        "confidence_mean": mean_conf,
        "confidence_std": std_conf,
        "confidence_trend": trend,
        "anomaly_rate": anomaly_rate
    }