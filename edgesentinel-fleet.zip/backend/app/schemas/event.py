from pydantic import BaseModel
from typing import Optional, Any
from datetime import datetime


class InferenceEventBase(BaseModel):
    device_id: int
    model_version_id: int
    confidence: Optional[float] = None
    features: Optional[Any] = None
    is_anomaly: Optional[bool] = False
    image_path: Optional[str] = None


class InferenceEventCreate(InferenceEventBase):
    pass


class InferenceEventUpdate(BaseModel):
    confidence: Optional[float] = None
    features: Optional[Any] = None
    is_anomaly: Optional[bool] = None
    image_path: Optional[str] = None


class InferenceEventInDBBase(InferenceEventBase):
    id: int
    timestamp: datetime

    class Config:
        orm_mode = True


class InferenceEventInDB(InferenceEventInDBBase):
    pass


class InferenceEvent(InferenceEventInDBBase):
    pass