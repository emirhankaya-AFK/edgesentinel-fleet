from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class AuditLogBase(BaseModel):
    device_id: Optional[int] = None
    user_id: Optional[str] = None
    action: str
    details: Optional[str] = None


class AuditLogCreate(AuditLogBase):
    pass


class AuditLogUpdate(BaseModel):
    device_id: Optional[int] = None
    user_id: Optional[str] = None
    action: Optional[str] = None
    details: Optional[str] = None


class AuditLogInDBBase(AuditLogBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class AuditLogInDB(AuditLogInDBBase):
    pass


class AuditLog(AuditLogInDBBase):
    pass