from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum


class ModelStatus(str, Enum):
    TRAINING = "training"
    STAGING = "staging"
    PRODUCTION = "production"
    DEPRECATED = "deprecated"


class ModelVersionBase(BaseModel):
    model_name: str
    version: str
    description: Optional[str] = None
    status: ModelStatus = ModelStatus.STAGING
    is_immutable: bool = False


class ModelVersionCreate(ModelVersionBase):
    pass


class ModelVersionUpdate(BaseModel):
    model_name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ModelStatus] = None
    is_immutable: Optional[bool] = None


class ModelVersionInDBBase(ModelVersionBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


class ModelVersionInDB(ModelVersionInDBBase):
    pass


class ModelVersion(ModelVersionInDBBase):
    pass