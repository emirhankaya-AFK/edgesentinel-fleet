from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class DeviceBase(BaseModel):
    device_id: str
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = True


class DeviceCreate(DeviceBase):
    pass


class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class DeviceInDBBase(DeviceBase):
    id: int
    last_seen: datetime
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True


class DeviceInDB(DeviceInDBBase):
    pass


class Device(DeviceInDBBase):
    pass