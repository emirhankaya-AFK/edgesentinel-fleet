from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class FeedbackBase(BaseModel):
    event_id: int
    device_id: int
    reviewer_id: str
    feedback_type: str
    comments: Optional[str] = None


class FeedbackCreate(FeedbackBase):
    pass


class FeedbackUpdate(BaseModel):
    feedback_type: Optional[str] = None
    comments: Optional[str] = None


class FeedbackInDBBase(FeedbackBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class FeedbackInDB(FeedbackInDBBase):
    pass


class Feedback(FeedbackInDBBase):
    pass