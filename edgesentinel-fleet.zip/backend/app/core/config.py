from pydantic import BaseSettings, Field
from typing import List, Union
import json


class Settings(BaseSettings):
    PROJECT_NAME: str = "EdgeSentinel"
    API_V1_STR: str = "/api/v1"
    # BACKEND_CORS_ORIGINS is a JSON-formatted list of origins
    # e.g: '["http://localhost", "http://localhost:4200", "http://localhost:3000"]'
    BACKEND_CORS_ORIGINS: Union[List[str], str] = []
    # DATABASE_URL: str = Field(..., env="DATABASE_URL")
    # For demo, we can use SQLite if DATABASE_URL is not set
    DATABASE_URL: str = Field(
        default="sqlite:///./test.db",
        env="DATABASE_URL"
    )
    # SECRET_KEY for JWT
    SECRET_KEY: str = Field(default="CHANGE_ME_TO_A_SECRET_KEY", env="SECRET_KEY")
    # 60 minutes * 24 hours * 8 days = 8 days
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8

    class Config:
        case_sensitive = True
        env_file = ".env"


settings = Settings()