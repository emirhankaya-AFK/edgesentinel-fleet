from sqlalchemy.orm import Session
from app.models.model import ModelVersion
from app.schemas.model import ModelVersionCreate, ModelVersionUpdate


def get_model_version(db: Session, model_version_id: int):
    return db.query(ModelVersion).filter(ModelVersion.id == model_version_id).first()


def get_model_version_by_name_and_version(db: Session, model_name: str, version: str):
    return db.query(ModelVersion).filter(
        ModelVersion.model_name == model_name,
        ModelVersion.version == version
    ).first()


def get_model_versions(db: Session, skip: int = 0, limit: int = 100):
    return db.query(ModelVersion).offset(skip).limit(limit).all()


def create_model_version(db: Session, model: ModelVersionCreate):
    db_model = ModelVersion(
        model_name=model.model_name,
        version=model.version,
        description=model.description,
        status=model.status,
        is_immutable=model.is_immutable
    )
    db.add(db_model)
    db.commit()
    db.refresh(db_model)
    return db_model


def update_model_version(db: Session, model_version_id: int, model: ModelVersionUpdate):
    db_model = get_model_version(db, model_version_id)
    if db_model:
        update_data = model.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_model, key, value)
        db.commit()
        db.refresh(db_model)
    return db_model


def delete_model_version(db: Session, model_version_id: int):
    db_model = get_model_version(db, model_version_id)
    if db_model:
        db.delete(db_model)
        db.commit()
    return db_model