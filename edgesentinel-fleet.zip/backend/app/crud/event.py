from sqlalchemy.orm import Session
from app.models.event import InferenceEvent
from app.schemas.event import InferenceEventCreate, InferenceEventUpdate


def get_event(db: Session, event_id: int):
    return db.query(InferenceEvent).filter(InferenceEvent.id == event_id).first()


def get_events_by_device(db: Session, device_id: int, skip: int = 0, limit: int = 100):
    return db.query(InferenceEvent).filter(
        InferenceEvent.device_id == device_id
    ).offset(skip).limit(limit).all()


def get_events_by_model_version(db: Session, model_version_id: int, skip: int = 0, limit: int = 100):
    return db.query(InferenceEvent).filter(
        InferenceEvent.model_version_id == model_version_id
    ).offset(skip).limit(limit).all()


def create_event(db: Session, event: InferenceEventCreate):
    db_event = InferenceEvent(
        device_id=event.device_id,
        model_version_id=event.model_version_id,
        confidence=event.confidence,
        features=event.features,
        is_anomaly=event.is_anomaly,
        image_path=event.image_path
    )
    db.add(db_event)
    db.commit()
    db.refresh(db_event)
    return db_event


def update_event(db: Session, event_id: int, event: InferenceEventUpdate):
    db_event = get_event(db, event_id)
    if db_event:
        update_data = event.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_event, key, value)
        db.commit()
        db.refresh(db_event)
    return db_event


def delete_event(db: Session, event_id: int):
    db_event = get_event(db, event_id)
    if db_event:
        db.delete(db_event)
        db.commit()
    return db_event