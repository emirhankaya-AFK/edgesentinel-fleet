from sqlalchemy.orm import Session
from app.models.alert import Alert
from app.schemas.alert import AlertCreate, AlertUpdate


def get_alert(db: Session, alert_id: int):
    return db.query(Alert).filter(Alert.id == alert_id).first()


def get_alerts_by_device(db: Session, device_id: int, skip: int = 0, limit: int = 100):
    return db.query(Alert).filter(Alert.device_id == device_id).offset(skip).limit(limit).all()


def create_alert(db: Session, alert: AlertCreate):
    db_alert = Alert(
        device_id=alert.device_id,
        event_id=alert.event_id,
        alert_type=alert.alert_type,
        message=alert.message,
        is_acknowledged=alert.is_acknowledged,
        acknowledged_by=alert.acknowledged_by,
        acknowledged_at=alert.acknowledged_at
    )
    db.add(db_alert)
    db.commit()
    db.refresh(db_alert)
    return db_alert


def update_alert(db: Session, alert_id: int, alert: AlertUpdate):
    db_alert = get_alert(db, alert_id)
    if db_alert:
        update_data = alert.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_alert, key, value)
        db.commit()
        db.refresh(db_alert)
    return db_alert


def delete_alert(db: Session, alert_id: int):
    db_alert = get_alert(db, alert_id)
    if db_alert:
        db.delete(db_alert)
        db.commit()
    return db_alert