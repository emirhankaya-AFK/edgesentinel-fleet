from sqlalchemy.orm import Session
from app.models.audit import AuditLog
from app.schemas.audit import AuditLogCreate, AuditLogUpdate


def get_audit_log(db: Session, audit_log_id: int):
    return db.query(AuditLog).filter(AuditLog.id == audit_log_id).first()


def get_audit_logs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(AuditLog).offset(skip).limit(limit).all()


def create_audit_log(db: Session, audit_log: AuditLogCreate):
    db_audit_log = AuditLog(
        device_id=audit_log.device_id,
        user_id=audit_log.user_id,
        action=audit_log.action,
        details=audit_log.details
    )
    db.add(db_audit_log)
    db.commit()
    db.refresh(db_audit_log)
    return db_audit_log


def update_audit_log(db: Session, audit_log_id: int, audit_log: AuditLogUpdate):
    db_audit_log = get_audit_log(db, audit_log_id)
    if db_audit_log:
        update_data = audit_log.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_audit_log, key, value)
        db.commit()
        db.refresh(db_audit_log)
    return db_audit_log


def delete_audit_log(db: Session, audit_log_id: int):
    db_audit_log = get_audit_log(db, audit_log_id)
    if db_audit_log:
        db.delete(db_audit_log)
        db.commit()
    return db_audit_log