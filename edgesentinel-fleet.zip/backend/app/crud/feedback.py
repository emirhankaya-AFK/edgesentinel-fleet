from sqlalchemy.orm import Session
from app.models.feedback import Feedback
from app.schemas.feedback import FeedbackCreate, FeedbackUpdate


def get_feedback(db: Session, feedback_id: int):
    return db.query(Feedback).filter(Feedback.id == feedback_id).first()


def get_feedback_by_event(db: Session, event_id: int, skip: int = 0, limit: int = 100):
    return db.query(Feedback).filter(Feedback.event_id == event_id).offset(skip).limit(limit).all()


def create_feedback(db: Session, feedback: FeedbackCreate):
    db_feedback = Feedback(
        event_id=feedback.event_id,
        device_id=feedback.device_id,
        reviewer_id=feedback.reviewer_id,
        feedback_type=feedback.feedback_type,
        comments=feedback.comments
    )
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    return db_feedback


def update_feedback(db: Session, feedback_id: int, feedback: FeedbackUpdate):
    db_feedback = get_feedback(db, feedback_id)
    if db_feedback:
        update_data = feedback.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_feedback, key, value)
        db.commit()
        db.refresh(db_feedback)
    return db_feedback


def delete_feedback(db: Session, feedback_id: int):
    db_feedback = get_feedback(db, feedback_id)
    if db_feedback:
        db.delete(db_feedback)
        db.commit()
    return db_feedback