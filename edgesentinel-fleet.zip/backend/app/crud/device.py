from sqlalchemy.orm import Session
from app.models.device import Device
from app.schemas.device import DeviceCreate, DeviceUpdate


def get_device(db: Session, device_id: int):
    return db.query(Device).filter(Device.id == device_id).first()


def get_device_by_device_id(db: Session, device_id_str: str):
    return db.query(Device).filter(Device.device_id == device_id_str).first()


def get_devices(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Device).offset(skip).limit(limit).all()


def create_device(db: Session, device: DeviceCreate):
    db_device = Device(
        device_id=device.device_id,
        name=device.name,
        description=device.description,
        is_active=device.is_active
    )
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return db_device


def update_device(db: Session, device_id: int, device: DeviceUpdate):
    db_device = get_device(db, device_id)
    if db_device:
        update_data = device.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_device, key, value)
        db.commit()
        db.refresh(db_device)
    return db_device


def delete_device(db: Session, device_id: int):
    db_device = get_device(db, device_id)
    if db_device:
        db.delete(db_device)
        db.commit()
    return db_device