# EdgeSentinel Architecture

## Overview

EdgeSentinel is designed as a microservices architecture with three primary components:

1. **Backend API Service** (FastAPI) - Central server for data storage, processing, and API exposure
2. **Frontend Dashboard** (React/Vite) - User interface for monitoring and management
3. **Edge Agent Simulator** (Python) - Simulates edge devices generating vision data

## Component Diagram

```
+------------------+     +------------------+     +------------------+
|   Frontend       |     |   Backend API    |     |   Edge Agent     |
|   Dashboard      |<--->|   (FastAPI)      |<--->|   Simulator      |
|   (React/Vite)   |     |   + DB (Postgres)|     |   (Python)       |
+------------------+     +------------------+     +------------------+
        ^                         ^                         ^
        |                         |                         |
        |        HTTP/WebSocket   |        HTTP             |
        +-------------------------+-------------------------+
```

## Data Flow

1. **Device Registration & Heartbeats**:
   - Edge agents register with the backend API on startup
   - Periodic heartbeats update the device's `last_seen` timestamp
   - Backend stores device status in PostgreSQL

2. **Camera Stream Simulation & Inference**:
   - Edge agents generate synthetic image data (features)
   - Run mock inference to produce confidence scores and anomaly flags
   - Send inference events to the backend API
   - Backend stores events and computes real-time metrics

3. **Model Registry & Rollout**:
   - Backend maintains a registry of model versions
   - Each model version has metadata: name, version, status (training/staging/production/deprecated), immutability flag
   - Edge agents report which model version they used for inference
   - Backend can track model performance across devices

4. **Event Processing & Alerting**:
   - Backend receives inference events
   - Computes drift metrics (confidence mean/std, trend, anomaly rate)
   - Generates alerts when thresholds are exceeded (low confidence, high anomaly rate, drift detected)
   - Alerts are stored and can be acknowledged via the API

5. **Human Review & Feedback**:
   - Events flagged for review can be assigned to human reviewers
   - Reviewers submit feedback (correct/incorrect/needs_review) with optional comments
   - Feedback is stored and can be used for model retraining

6. **Audit Logging**:
   - All significant actions (device registration, model rollout, alert acknowledgement, feedback submission) are logged
   - Audit logs include actor, action, timestamp, and details

7. **Offline Support**:
   - Edge agents cache events locally when backend is unreachable
   - On reconnection, cached events are sent with retry logic
   - Implemented with exponential backoff and maximum queue size

## Technology Stack

### Backend
- **Language**: Python 3.9+
- **Framework**: FastAPI for high-performance async API
- **Database**: SQLAlchemy ORM with PostgreSQL (SQLite for demo)
- **Migrations**: Alembic (not implemented in demo but ready)
- **Validation**: Pydantic models for request/response validation
- **Async Communication**: WebSocket endpoint for real-time event feed

### Frontend
- **Language**: TypeScript
- **Framework**: React 18 with Vite for fast builds
- **State Management**: React Context or lightweight state management (can be extended to Redux/Zustand)
- **Routing**: React Router v6
- **HTTP Client**: Axios for API communication
- **UI Framework**: Can be extended with Material-UI or Ant Design

### Edge Agent
- **Language**: Python 3.9+
- **Dependencies**: requests for HTTP communication
- **Simulation**: Synthetic data generation and mock inference functions

## Deployment Options

### Docker Compose (Development/Demo)
- Orchestrates backend, frontend, edge-agent, and PostgreSQL
- Ideal for local development and demonstrations

### Kubernetes (Production)
- Separate Deployments and Services for each component
- PersistentVolumeClaim for PostgreSQL data persistence
- ConfigMaps and Secrets for configuration management
- Horizontal Pod Autoscaler ready for backend and frontend

## Scalability Considerations

- **Backend**: Stateless API servers behind a load balancer
- **Database**: PostgreSQL can be scaled vertically or with read replicas
- **Frontend**: Can be served via CDN and scaled horizontally
- **Edge Agents**: Designed to run independently; backend scales with number of agents
- **Event Processing**: Can be offloaded to message queues (e.g., Redis, RabbitMQ) for high throughput

## Extensibility

- **Authentication**: Pluggable authentication system (JWT/OAuth2) can be added
- **Message Queue**: Replace direct HTTP POST with message queue for event ingestion
- **Storage Layer**: Swap PostgreSQL for other databases via SQLAlchemy dialect
- **ML Integration**: Replace mock inference with real model serving (TensorFlow Serving, TorchServe)
- **UI Theming**: Extendable theming system for white-label deployments