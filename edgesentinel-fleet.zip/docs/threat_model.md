# EdgeSentinel Threat Model

## Scope

This threat model covers the EdgeSentinel system as described in the architecture, including:
- Backend API service (FastAPI)
- Frontend dashboard (React/Vite)
- Edge agent simulator (Python)
- PostgreSQL database
- Communication channels between components

## Assets

1. **Data Assets**:
   - Device registry (device IDs, metadata, status)
   - Model registry (model versions, metadata)
   - Inference events (confidence scores, features, timestamps)
   - Alerts and feedback
   - Audit logs

2. **Service Assets**:
   - Backend API availability and integrity
   - Frontend availability and integrity
   - Edge agent availability and integrity

3. **Infrastructure Assets**:
   - Database integrity and availability
   - Network infrastructure

## Threat Actors

1. **External Attacker**: Internet-based attacker with no prior access
2. **Malicious Insider**: Authorized user with malicious intent
3. **Compromised Edge Agent**: Edge agent that has been taken over by an attacker
4. **Supply Chain Attacker**: Attacker targeting dependencies or build process

## Threats and Mitigations

### T1: Unauthorized Access to Backend API
- **Description**: Attacker gains access to backend endpoints without proper authentication
- **Mitigations**:
  - Implement JWT-based authentication for all API endpoints
  - Use HTTPS in production to protect tokens in transit
  - Implement rate limiting to prevent brute force attacks
  - Use API gateway or service mesh for centralized auth and traffic management

### T2: Data Breach via Database Exposure
- **Description**: Attacker gains unauthorized access to PostgreSQL database
- **Mitigations**:
  - Encrypt database at rest
  - Use strong passwords and rotate credentials regularly
  - Restrict database network access to only backend services
  - Enable database audit logging
  - Regularly backup and test restoration procedures

### T3: Man-in-the-Middle (MitM) Attacks
- **Description**: Attacker intercepts or modifies communication between components
- **Mitigations**:
  - Use mutual TLS (mTLS) for service-to-service communication
  - Use HTTPS for all web traffic
  - Implement certificate pinning in edge agents
  - Use secure WebSocket (WSS) for real-time feeds

### T4: Compromised Edge Agent
- **Description**: An edge agent is taken over and used to send malicious data
- **Mitigations**:
  - Implement device authentication using device-specific certificates or tokens
  - Implement anomaly detection on incoming events (e.g., impossible confidence scores, malformed features)
  - Implement device reputation system; temporarily distrust devices sending anomalous data
  - Enable secure boot and device attestation for hardware-based edge devices
  - Implement edge agent update mechanism with signed packages

### T5: Injection Attacks (SQL, NoSQL, Command)
- **Description**: Attacker injects malicious code via input fields
- **Mitigations**:
  - Use ORM (SQLAlchemy) which prevents SQL injection by design
  - Validate and sanitize all inputs using Pydantic models
  - Implement proper output encoding in frontend to prevent XSS
  - Use dependency scanning tools to identify vulnerable libraries

### T6: Denial of Service (DoS)
- **Description**: Attacker overwhelms system resources to make service unavailable
- **Mitigations**:
  - Implement rate limiting on API endpoints
  - Use cloudflare or similar DDoS protection services
  - Implement autoscaling for backend and frontend
  - Use CDN for frontend delivery
  - Implement connection limits and timeouts

### T7: Data Tampering
- **Description**: Attacker alters data in transit or at rest
- **Mitigations**:
  - Use cryptographic hashes (e.g., SHA-256) for data integrity verification
  - Implement digital signatures for critical data (e.g., model versions, audit logs)
  - Use immutable storage for audit logs (write-once storage)
  - Implement blockchain-style chaining for audit logs (each log entry hashes previous)

### T8: Privilege Escalation
- **Description**: Attacker gains higher privileges than intended
- **Mitigations**:
  - Implement principle of least privilege for all service accounts
  - Use separate database users for different functions (read/write)
  - Implement role-based access control (RBAC) in backend
  - Regularly audit user permissions and access logs

### T9: Supply Chain Attack
- **Description**: Attacker compromises dependencies or build process
- **Mitigations**:
  - Use software bill of materials (SBOM) for all components
  - Implement dependency scanning in CI/CD pipeline
  - Use locked dependency files (requirements.txt, package-lock.json)
  - Sign build artifacts and verify signatures before deployment
  - Use private package registries for internal dependencies

### T10: Insufficient Logging and Monitoring
- **Description**: Lack of adequate logs prevents detection of attacks
- **Mitigations**:
  - Implement comprehensive logging for all security-relevant events
  - Centralize logs using ELK stack or similar
  - Set up alerts for suspicious patterns (e.g., multiple failed logins, unusual data volumes)
  - Regularly review logs and conduct penetration testing

## Security Features by Design

1. **Role-Ready Architecture**: Designed to support RBAC from the ground up
2. **Immutable Model Versions**: Critical model versions can be marked as immutable to prevent tampering
3. **Audit Trail**: All system changes are logged for forensic analysis
4. **Input Validation**: Strict validation at API boundaries
5. **Separation of Concerns**: Clear separation between API, frontend, and edge agent responsibilities
6. **Secure Defaults**: Conservative security settings that can be tightened for production

## Recommendations for Production Deployment

1. **Network Segmentation**:
   - Place backend and database in private network segment
   - Place frontend in DMZ with WAF
   - Edge agents operate in their respective networks (factory floors, etc.)

2. **Identity and Access Management**:
   - Integrate with enterprise IdP (LDAP, Active Directory, SAML)
   - Use hardware security modules (HSM) for key management
   - Implement just-in-time (JIT) access for privileged operations

3. **Data Protection**:
   - Encrypt sensitive data fields (e.g., feedback comments may contain PII)
   - Implement data loss prevention (DLP) for outbound traffic
   - Regularly scan for and remediate vulnerabilities

4. **Monitoring and Response**:
   - Deploy intrusion detection systems (IDS) at network boundaries
   - Implement security information and event management (SIEM)
   - Establish incident response plan and conduct regular drills

5. **Regular Assessments**:
   - Conduct quarterly penetration testing
   - Perform monthly vulnerability scanning
   - Review and update threat model annually or when significant changes occur