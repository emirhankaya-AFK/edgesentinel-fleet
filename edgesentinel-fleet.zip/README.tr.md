# EdgeSentinel: Kenar AI Görüşü Armada Yönetimi

EdgeSentinel, kenar AI görüşü cihazlarının armadalarını yönetmek için kapsamlı bir portföy ürünüdür. Cihaz kaydı, heartbeats izleme, kamera akışı simülasyonu, değiştirilemeyen sürümler ve dağıtım étatsı olan model kayıtları, çıkarım eventi girişi, alert onayı, insan inceleme/geri bildirim döngüsü, sapma metrikleri hesaplama, çevrimdışı kenar kuyruğu ile yeniden deneme/senkronizasyon davranışı, denetim günlüğü ve rol hazır mimarisi sağlar.

## Özellikler

- **Cihaz Yönetimi**: Kenar cihazlarını heartbeats üzerinden kaydedin ve izleyin
- **Model Kayıt Defteri**: Değiştirilemeyen bayraklar ve dağıtım étatsı olan AI model sürümlerini saklayın ve yönetin
- **Etki Girişi**: Kenar cihazlarından çıkarım eventlerini alın ve işleyin
- **Uyarılandırma**: Sapma, düşük güvenilirlik veya anomali üzerine uyarılar oluşturun
- **İnsan İnceleme**: Çıkarım üzerine insan geri bildirimi için iş akışı
- **Sapma Algılama**: Event güvenirlilik ve özellik istatistiklerinden sapma metriklerini hesaplayın
- **Çevrimdışı Destek**: Kenar ajanı çevrimdışı olduğunda eventleri kuyruğa alır ve çevrimiçi olduğunda senkronize eder
- **Denetim Günlüğü**: Sistemdeki tüm eylemler için kapsamlı denetim yolu
- **Rol Hazır Mimari**: Rol tabanlı erişim kontrolü (RBAC) desteklemek üzere tasarlandı

## Mimari

Detaylı mimari diyagramları ve açıklamaları için [docs/architecture.md](docs/architecture.md) dosyasına bakın.

## API Dokümantasyonu

REST API ve WebSocket event akışı dokümantasyonu için [docs/api.md](docs/api.md) dosyasına bakın.

## Tehdit Modeli

Güvenlik konuları ve tehdit azaltma stratejileri için [docs/threat_model.md](docs/threat_model.md) dosyasına bakın.

## Başlarken

### Ön Koşullar

- Docker ve Docker Compose
- (İsteğe bağlı) Üretim dağıtımı için Kubernetes kümesi

### Docker Compose ile Çalıştırma

1. Depoyu klonlayın
2. Proje dizinine gidin
3. Örnek ortam dosyasını kopyalayın:
   ```bash
   cp backend/.env.example backend/.env
   ```
4. Gerekirse `.env` dosyasını düzenleyin (PostgreSQL bağlantısı için)
5. Hizmetleri başlatın:
   ```bash
   make up
   ```
6. Kontrol paneli http://localhost:3000 adresine erişin
7. Backend API'si http://localhost:8000 adresinde kullanılabilir

### Kubernetes ile Çalıştırma

1. Veritabanı depolama sınıfı ve PVC uygulayın (henüz mevcut değilse)
2. Kubernetes bildirimlerini uygulayın:
   ```bash
   kubectl apply -f kubernetes/
   ```
3. Frontend'e LoadBalancer hizmeti üzerinden veya bir Ingress kurarak erişin

### Örnek Veri

Veritabanına örnek veri eklemek için örnek veri betiğini çalıştırın:
```bash
# Docker Compose kullanarak
docker-compose run --rm backend python kubernetes/scripts/sample_data.py

# Kubernetes kullanarak
kubectl run --rm -i --tty sample-data --image=edgesentinel-backend:latest --restart=Never -- \
  python kubernetes/scripts/sample_data.py
```

## Geliştirme

### Backend

- Teknoloji: FastAPI, SQLAlchemy, Pydantic
- Test: `make test` komutunu çalıştırarak backend testlerini çalıştırın

### Frontend

- Teknoloji: React, TypeScript, Vite
- Geliştirme: `make frontend` komutu frontend'i geliştirme modunda başlatır

### Edge Agent Simülatörü

- Teknoloji: Python
- Amaç: Sentetik görüş verisi oluşturan kenar cihazlarını simüle eder

## Lisans

Bu proje özel ve gizlidir. Tüm hakları saklıdır.

## İletişim

Sorularınız için [iletişim bilgileriniz buraya] ile iletişime geçebilirsiniz.