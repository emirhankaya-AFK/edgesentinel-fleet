"""
Sample data script for EdgeSentinel.
Populates the database with initial devices, model versions, and events.
"""
import sys
import os
sys.path.append("/app/backend")

from sqlalchemy.orm import Session
from app.core.database import SessionLocal, engine
from app.models.device import Device
from app.models.model import ModelVersion, ModelStatus
from app.models.event import InferenceEvent
from app.core.config import settings
from app.utils import generate_synthetic_image_data, mock_inference
import random
from datetime import datetime, timedelta

def create_sample_data():
    db = SessionLocal()
    try:
        # Create tables if they don't exist
        from app.core.database import Base
        Base.metadata.create_all(bind=engine)

        # Check if we already have data
        if db.query(Device).first():
            print("Sample data already exists. Skipping.")
            return

        # Create sample devices
        devices = [
            Device(device_id="edge-device-001", name="Factory Camera 1", description="Monitoring production line A", is_active=True),
            Device(device_id="edge-device-002", name="Factory Camera 2", description="Monitoring production line B", is_active=True),
            Device(device_id="edge-device-003", name="Warehouse Camera 1", description="Monitoring warehouse entrance", is_active=True),
        ]
        for device in devices:
            db.add(device)
        db.commit()

        # Create sample model versions
        model_versions = [
            ModelVersion(model_name="vision-model-v1", version="1.0.0", description="Initial vision model", status=ModelStatus.PRODUCTION, is_immutable=True),
            ModelVersion(model_name="vision-model-v1", version="1.1.0", description="Improved accuracy", status=ModelStatus.STAGING, is_immutable=False),
            ModelVersion(model_name="vision-model-v2", version="2.0.0", description="New architecture", status=ModelStatus.TRAINING, is_immutable=False),
        ]
        for mv in model_versions:
            db.add(mv)
        db.commit()

        # Create sample inference events for each device
        for device in devices:
            # Assign a random model version for each event
            for i in range(10):  # 10 events per device
                model_version = random.choice(model_versions)
                # Generate synthetic features
                features = generate_synthetic_image_data()
                confidence, is_anomaly = mock_inference(
                    model_version.model_name,
                    model_version.version,
                    features
                )
                # Random timestamp within the last 24 hours
                timestamp = datetime.now() - timedelta(hours=random.uniform(0, 24))
                event = InferenceEvent(
                    device_id=device.id,
                    model_version_id=model_version.id,
                    confidence=confidence,
                    features=features,
                    is_anomaly=is_anomaly,
                    timestamp=timestamp
                )
                db.add(event)
        db.commit()

        print("Sample data created successfully.")
    except Exception as e:
        print(f"Error creating sample data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_sample_data()