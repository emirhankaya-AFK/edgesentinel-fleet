import time
import json
import requests
import random
from datetime import datetime
from app.utils import generate_synthetic_image_data, mock_inference

# Configuration
BACKEND_URL = "http://backend:8000/api/v1"  # In docker-compose, backend service is reachable at this URL
DEVICE_ID = "edge-simulator-001"
MODEL_NAME = "mock-vision-model"
MODEL_VERSION = "1.0.0"

def register_device():
    """Register the device with the backend."""
    url = f"{BACKEND_URL}/devices/"
    payload = {
        "device_id": DEVICE_ID,
        "name": "Edge Agent Simulator",
        "description": "Simulated edge device for EdgeSentinel",
        "is_active": True
    }
    try:
        response = requests.post(url, json=payload)
        if response.status_code == 201:
            print(f"Device {DEVICE_ID} registered successfully.")
        elif response.status_code == 400:
            print(f"Device {DEVICE_ID} already registered.")
        else:
            print(f"Failed to register device: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error registering device: {e}")

def send_heartbeat():
    """Send a heartbeat to the backend to update last_seen."""
    url = f"{BACKEND_URL}/devices/{DEVICE_ID}"
    # We'll update the device by sending a PATCH-like update (we'll use PUT for simplicity)
    # In a real scenario, we might have a specific heartbeat endpoint.
    # For now, we'll just update the device with the same data to refresh the timestamp.
    payload = {
        "device_id": DEVICE_ID,
        "name": "Edge Agent Simulator",
        "description": "Simulated edge device for EdgeSentinel",
        "is_active": True
    }
    try:
        response = requests.put(url, json=payload)
        if response.status_code == 200:
            print(f"Heartbeat sent for {DEVICE_ID}.")
        else:
            print(f"Failed to send heartbeat: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error sending heartbeat: {e}")

def simulate_inference_and_send_event():
    """Generate synthetic data, run mock inference, and send event to backend."""
    # Generate synthetic image features
    features = generate_synthetic_image_data()
    
    # Run mock inference
    confidence, is_anomaly = mock_inference(MODEL_NAME, MODEL_VERSION, features)
    
    # Prepare event payload
    event_payload = {
        "device_id": DEVICE_ID,  # This will be resolved to device ID in backend via lookup
        "model_version_id": 1,   # We assume model version ID 1 exists; in reality, we'd look it up
        "confidence": confidence,
        "features": features,
        "is_anomaly": is_anomaly
    }
    
    # Send event to backend
    url = f"{BACKEND_URL}/events/"
    try:
        response = requests.post(url, json=event_payload)
        if response.status_code == 201:
            print(f"Event sent: confidence={confidence:.2f}, anomaly={is_anomaly}")
        else:
            print(f"Failed to send event: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error sending event: {e}")

def main():
    print("Starting Edge Agent Simulator...")
    
    # Register device
    register_device()
    
    # Main loop
    while True:
        # Send heartbeat every 30 seconds
        send_heartbeat()
        
        # Simulate inference and send event every 10 seconds
        simulate_inference_and_send_event()
        
        # Wait for 10 seconds before next iteration
        time.sleep(10)

if __name__ == "__main__":
    main()